import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';
import App from './App';
import reportWebVitals from './reportWebVitals';
import { createBrowserRouter, RouterProvider } from 'react-router-dom';
import Dashboard from './componets/Dashboard';
import Customers from './componets/Customers';
import Products, {loader as productsLoader} from './componets/Products';
import Orders from './componets/Orders';
import Reporsts from './componets/Reports';
import Provinces, {loader as provincesLoader} from './componets/Provinces';
import Categories, {loader as categoriesLoader} from './componets/Categories';
import Users, {loader as usersLoader} from './componets/Users';



let provinces = [
  {
    id: 1001, name: 'guilan', cities: [
      { id: 2001, name: 'rasht' },
      { id: 2002, name: 'lahijan' },
      { id: 2003, name: 'langroud' },
    ]
  },
  {
    id: 1002, name: 'tehran', cities: [
      { id: 2001, name: 'tehran' },
      { id: 2002, name: 'varamin' },
      { id: 2003, name: 'damavand' },
    ]
  },
]
localStorage.setItem('provinces', JSON.stringify(provinces))

let users = [
  { id: 3001, name: 'ali', username: 'ali1234', password: '1234' },
  { id: 3002, name: 'mehran', username: 'mehran1234', password: '2536' },
  { id: 3003, name: 'amir', username: 'amir1234', password: '4507' },
]
localStorage.setItem('users', JSON.stringify(users))

let categories = [
  { id: 4001, name: 'pc' },
  { id: 4002, name: 'laptop' },
  { id: 4003, name: 'mobile' },
  { id: 4004, name: 'tv' },
  { id: 4005, name: 'camera' },
]
localStorage.setItem('categories', JSON.stringify(categories))

let brands = [
  { id: 5001, name: 'adidas' },
  { id: 5002, name: 'lenovo' },
  { id: 5003, name: 'asus' },
  { id: 5004, name: 'apple' },
]
localStorage.setItem('brands', JSON.stringify(brands))

let products = [
  { id: 6001, name: 'rogg14', brand: 'asus', categories: ['laptop'], stock: false, price: 120000000 },
  { id: 6002, name: 'Galaxy A54', brand: 'samsung', categories: ['mobile', 'laptop'], stock: true, price: 250000000 },
  { id: 6003, name: 'QLED', brand: 'samsung', categories: ['tv'], stock: false, price: 360000000 },
  { id: 6004, name: 'AllinOnes', brand: 'samsung', categories: ['pc'], stock: true, price: 125000000 },
  { id: 6005, name: 'APS', brand: 'sony', categories: ['camera'], stock: true, price: 88000000 },
  { id: 6006, name: 'j7', brand: 'asus', categories: ['mobile'], stock: false, price: 63000000 },
  { id: 6007, name: 'rogg14', brand: 'asus', categories: ['laptop'], stock: false, price: 750000000 },
  { id: 6008, name: 'EOS', brand: 'canon', categories: ['camera'], stock: true, price: 365000000 },
  { id: 6009, name: 'Oled', brand: 'lg', categories: ['tv'], stock: true, price: 77000000 },
  { id: 6010, name: 'A32', brand: 'samsung', categories: ['mobile'], stock: false, price: 45000000 },
]
localStorage.setItem('products', JSON.stringify(products))

let customers = [
  { id: 7001, name: 'mehdi', family: 'alavi', address: ['', ''], province: 'guilan', city: 'rasht' },
  { id: 7001, name: 'amir', family: 'derakhshan', address: ['', ''], province: 'tehran', city: 'varamin' },
  { id: 7001, name: 'amin', family: 'safavi', address: ['', ''], province: 'guilan', city: 'langroud' },
  { id: 7001, name: 'saeid', family: 'sasani', address: ['', ''], province: 'guilan', city: 'lahijan' },
  { id: 7001, name: 'soheil', family: 'naderpour', address: ['', ''], province: 'tehran', city: 'damavand' }
]
localStorage.setItem('customers', JSON.stringify(customers))


const router = createBrowserRouter([
  {
    path: '/',
    element: <App />,
    children: [
      {
        path: 'dashboard',
        element: <Dashboard />
      },
      {
        path: 'customers',
        element: <Customers />
      },
      {
        path: 'products',
        element: <Products />,
        loader: productsLoader
      },
      {
        path: 'orders',
        element: <Orders />
      },
      {
        path: 'reports',
        element: <Reporsts />
      },
      {
        path: 'provinces',
        element: <Provinces />,
        loader: provincesLoader
      },
      {
        path: 'categories',
        element: <Categories />,
        loader: categoriesLoader
      },
      {
        path: 'users',
        element: <Users />,
        loader: usersLoader
      },
    ]
  }
])

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <React.StrictMode>
    <RouterProvider router={router} />
  </React.StrictMode>
);

// If you want to start measuring performance in your app, pass a function
// to log results (for example: reportWebVitals(console.log))
// or send to an analytics endpoint. Learn more: https://bit.ly/CRA-vitals
reportWebVitals();
