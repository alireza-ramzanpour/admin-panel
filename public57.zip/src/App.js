import React from "react";
import { Link, Outlet } from "react-router-dom";
import './style.css'
import './componets/file'

function App() {
  return (
    <>
      <div className="nav-wrapper">
        <div className="left-nav">
          <h1 className="admin-title">Admin Panel</h1>
        </div>
        <div className="right-nav">
          <span className="admin-date">Last access : 30 May 2014</span>
          <input type="button" className="logout-btn" value="Logout" />
        </div>
      </div>

      <div className="main-wrapper">
        <div className="left-context">
          <div className="user-image">
            <img src="image/find_user.png" alt="USER" />
          </div>
          <div className="menu">
            <ul className="items">
              <Link to='/dashboard' className='menu-link'>
                <li className="item">
                  <i className="fa fa-dashboard fa-2x"></i>
                  <span>Dashboard</span>
                </li>
              </Link>
              <Link to='/customers' className='menu-link'>
                <li className="item">
                  <i className="fa fa-users fa-2x"></i>
                  <span>Customers</span>
                </li>
              </Link>
              <Link to='/products' className='menu-link'>
                <li className="item">
                  <i className="fa fa-qrcode fa-2x"></i>
                  <span>Products</span>
                </li>
              </Link>
              <Link to='/orders' className='menu-link'>
                <li className="item">
                  <i className="fa fa-shopping-bag fa-2x"></i>
                  <span>Orders</span>
                </li>
              </Link>
              <Link to='/reports' className='menu-link'>
                <li className="item">
                  <i className="fa fa-newspaper-o fa-2x"></i>
                  <span>Reporsts</span>
                </li>
              </Link>
              <Link to='/provinces' className='menu-link'>
                <li className="item">
                  <i className="fa fa-map-marker fa-2x"></i>
                  <span>Provinces</span>
                </li>
              </Link>
              <p className="info-text">Info</p>
              <Link to='/categories' className='menu-link'>
                <li className="item">
                  <i className="fa fa-sitemap fa-2x"></i>
                  <span>Categories</span>
                </li>
              </Link>
              <Link to='/users' className='menu-link'>
                <li className="item">
                  <i className="fa fa-user fa-2x"></i>
                  <span>Users</span>
                </li>
              </Link>
            </ul>
          </div>
        </div>
        <div className="right-context">
          <div className="page-wrapper">
            <Outlet />
          </div>
        </div>
      </div>
    </>
  );
}

export default App;
