import React from "react";
import { useLoaderData } from "react-router-dom";



export function loader(data) {
    const categories = JSON.parse(localStorage.getItem('categories'))
    return categories
}


function Categories() {
    let users = useLoaderData()
    return (
        <>
            <h1>Categories Page is Here</h1>

            <table className="styled-table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Name</th>
                    </tr>
                </thead>
                <tbody>
                    {
                        users.map((user) => (
                            <tr>
                                <td>{user.id}</td>
                                <td>{user.name}</td>
                            </tr>
                        ))
                    }
                </tbody>
            </table>

        </>
    );
}

export default Categories;