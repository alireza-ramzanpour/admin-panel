import React from "react";


function Orders() {
    return (
        <>

            <h1>Orders Page is Here</h1>



        </>
    );
}

export default Orders;