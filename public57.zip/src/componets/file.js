let liElems = document.querySelectorAll('li');

liElems.forEach((liElem) => {
    liElem.addEventListener('click', function () {
        if (!liElem.classList.contains('clipPath')) {
            liElems.forEach((otherLiElem) => {
                otherLiElem.classList.remove('clipPath');
            });
            liElem.classList.add('clipPath');
        }
    });
});