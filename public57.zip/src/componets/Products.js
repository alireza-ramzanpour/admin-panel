import React from "react";
import { useLoaderData } from "react-router-dom";
import '../style.css'

export function loader(data) {
    const products = JSON.parse(localStorage.getItem('products'))
    return products
}

function Products() {
    let products = useLoaderData()
    return (
        <>
            <h1>Products Page is Here</h1>

            <table className="styled-table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Brand</th>
                        <th>Categories</th>
                        <th>Stock</th>
                        <th>Prices</th>
                    </tr>
                </thead>
                <tbody>
                    {
                        products.map((product) => (
                            <tr>
                                <td>{product.id}</td>
                                <td>{product.name}</td>
                                <td>{product.brand}</td>
                                <td>{product.categories.join(', ')}</td>
                                <td>
                                    <input type="checkbox" disabled defaultChecked={product.stock} />
                                </td>
                                <td>{product.price.toLocaleString()}</td>
                            </tr>
                        ))
                    }
                </tbody>
            </table>


        </>
    );
}

export default Products;