import React from "react";


function Customers() {
    return (
        <>

            <h1>Customers Page is Here</h1>



        </>
    );
}

export default Customers;